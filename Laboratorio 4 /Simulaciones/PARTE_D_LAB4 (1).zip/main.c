
#define F_CPU 16000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <util/delay.h>
#include <stdint.h>

/* =====================================================
   JUEGO DE MEMORIA - ATmega328P
   Matriz WS2812B RGB 8x8
   Joystick KY-023
   Buzzer
   EEPROM para guardar nivel y record
   ===================================================== */

/* ---------------- PINES ---------------- */

// Matriz WS2812B: DIN conectado a PD6 (Arduino D6)
#define LED_DDR   DDRD
#define LED_PORT  PORTD
#define LED_PIN   PD6

// Joystick
#define JOY_X     PC0       // A0
#define JOY_Y     PC1       // A1
#define JOY_SW    PD2       // D2

// Buzzer
#define BUZZER_PIN PD3      // D3

#define TOTAL_LEDS 64
#define MAX_SECUENCIA 64

/* ---------------- COLORES ---------------- */

#define ROJO       0
#define VERDE      1
#define AZUL       2
#define AMARILLO   3

/* ---------------- ESTADOS ---------------- */

#define MODO_LIBRE      0
#define MOSTRAR         1
#define TURNO_JUGADOR   2
#define EXITO           3
#define ERROR_JUEGO     4

/* ---------------- ESTRUCTURAS ---------------- */

typedef struct
{
    uint8_t x;
    uint8_t y;
    uint8_t color;
} Elemento;

typedef struct
{
    uint16_t marca;
    uint8_t nivel;
    uint8_t record;
    uint8_t longitud;
    uint8_t indice;
    uint8_t cursorX;
    uint8_t cursorY;
    uint8_t colorCursor;
    uint8_t estado;
    Elemento secuencia[MAX_SECUENCIA];
} DatosGuardados;

/* ---------------- VARIABLES ---------------- */

static Elemento secuencia[MAX_SECUENCIA];

static uint8_t nivel = 1;
static uint8_t record = 0;
static uint8_t longitud = 1;
static uint8_t indiceJugador = 0;

static uint8_t cursorX = 3;
static uint8_t cursorY = 3;
static uint8_t colorCursor = VERDE;

static uint8_t estado = MODO_LIBRE;
static uint8_t semilla = 37;

static uint8_t botonAnterior = 1;
static uint16_t tiempoPulsado = 0;

/* ---------------- EEPROM ---------------- */

#define MARCA_EEPROM 0xA65C

DatosGuardados EEMEM memoriaJuego;

/* =====================================================
   CONTROL DE BUZZER
   ===================================================== */

static void esperar_ms(uint16_t ms)
{
    while (ms--)
        _delay_ms(1);
}

static void buzzer(uint16_t frecuencia, uint16_t duracion)
{
    if (frecuencia == 0)
    {
        esperar_ms(duracion);
        PORTD &= ~(1 << BUZZER_PIN);
        return;
    }

    uint16_t periodo = 1000000UL / frecuencia;
    uint16_t semiperiodo = periodo / 2;
    uint32_t ciclos = ((uint32_t)frecuencia * duracion) / 1000;

    while (ciclos--)
    {
        PORTD |= (1 << BUZZER_PIN);

        for (uint16_t i = 0; i < semiperiodo; i++)
            _delay_us(1);

        PORTD &= ~(1 << BUZZER_PIN);

        for (uint16_t i = 0; i < semiperiodo; i++)
            _delay_us(1);
    }

    PORTD &= ~(1 << BUZZER_PIN);
}

static void sonidoColor(uint8_t color)
{
    switch (color)
    {
        case ROJO:     buzzer(440, 120); break;
        case VERDE:    buzzer(554, 120); break;
        case AZUL:     buzzer(659, 120); break;
        case AMARILLO: buzzer(784, 120); break;
        default:       buzzer(300, 100); break;
    }
}

/* =====================================================
   MATRIZ WS2812B
   Orden de datos: GRB
   ===================================================== */

/*
   Esta rutina transmite cada byte al WS2812B.
   La temporización debe comprobarse en la simulación.
*/

static void ws2812_enviarByte(uint8_t dato)
{
    for (uint8_t i = 0; i < 8; i++)
    {
        if (dato & 0x80)
        {
            LED_PORT |= (1 << LED_PIN);
            _delay_us(0.65);

            LED_PORT &= ~(1 << LED_PIN);
            _delay_us(0.55);
        }
        else
        {
            LED_PORT |= (1 << LED_PIN);
            _delay_us(0.30);

            LED_PORT &= ~(1 << LED_PIN);
            _delay_us(0.90);
        }

        dato <<= 1;
    }
}

static void ws2812_enviarColor(uint8_t rojo,
                              uint8_t verde,
                              uint8_t azul)
{
    uint8_t interrupciones = SREG;
    cli();

    // El WS2812B recibe los componentes en orden GRB.
    ws2812_enviarByte(verde);
    ws2812_enviarByte(rojo);
    ws2812_enviarByte(azul);

    SREG = interrupciones;
}

static void matrizMostrar(void)
{
    _delay_us(80);
}

static void matrizLimpiar(void)
{
    for (uint8_t i = 0; i < TOTAL_LEDS; i++)
        ws2812_enviarColor(0, 0, 0);

    matrizMostrar();
}

static void colorRGB(uint8_t color,
                     uint8_t *rojo,
                     uint8_t *verde,
                     uint8_t *azul)
{
    switch (color)
    {
        case ROJO:
            *rojo = 255;
            *verde = 0;
            *azul = 0;
            break;

        case VERDE:
            *rojo = 0;
            *verde = 255;
            *azul = 0;
            break;

        case AZUL:
            *rojo = 0;
            *verde = 0;
            *azul = 255;
            break;

        case AMARILLO:
            *rojo = 255;
            *verde = 100;
            *azul = 0;
            break;

        default:
            *rojo = 0;
            *verde = 0;
            *azul = 0;
            break;
    }
}

/*
   Indexación lógica:
   x = columna (0 a 7)
   y = fila (0 a 7)

   Si la orientación física de la matriz es diferente,
   habrá que adaptar este cálculo.
*/

static void matrizPixel(uint8_t x, uint8_t y, uint8_t color)
{
    if (x > 7 || y > 7)
        return;

    uint8_t rojo, verde, azul;
    uint8_t posicion = y * 8 + x;

    colorRGB(color, &rojo, &verde, &azul);

    uint8_t interrupciones = SREG;
    cli();

    for (uint8_t i = 0; i < TOTAL_LEDS; i++)
    {
        if (i == posicion)
            ws2812_enviarColor(rojo, verde, azul);
        else
            ws2812_enviarColor(0, 0, 0);
    }

    SREG = interrupciones;
    matrizMostrar();
}

static void matrizCursor(void)
{
    matrizPixel(cursorX, cursorY, colorCursor);
}

/* =====================================================
   GENERADOR PSEUDOALEATORIO
   ===================================================== */

static uint8_t aleatorio(void)
{
    semilla ^= semilla << 3;
    semilla ^= semilla >> 5;
    semilla ^= semilla << 1;

    return semilla;
}

static void generarElemento(uint8_t posicion)
{
    secuencia[posicion].x = aleatorio() % 8;
    secuencia[posicion].y = aleatorio() % 8;
    secuencia[posicion].color = aleatorio() % 4;
}

static void generarNuevoElemento(void)
{
    if (longitud < MAX_SECUENCIA)
    {
        generarElemento(longitud);
        longitud++;
    }
}

/* =====================================================
   GUARDADO Y RECUPERACIÓN EEPROM
   ===================================================== */

static void guardarJuego(void)
{
    DatosGuardados datos;

    datos.marca = MARCA_EEPROM;
    datos.nivel = nivel;
    datos.record = record;
    datos.longitud = longitud;
    datos.indice = indiceJugador;
    datos.cursorX = cursorX;
    datos.cursorY = cursorY;
    datos.colorCursor = colorCursor;
    datos.estado = estado;

    for (uint8_t i = 0; i < MAX_SECUENCIA; i++)
        datos.secuencia[i] = secuencia[i];

    eeprom_update_block(&datos, &memoriaJuego, sizeof(datos));
}

static void cargarJuego(void)
{
    DatosGuardados datos;

    eeprom_read_block(&datos, &memoriaJuego, sizeof(datos));

    if (datos.marca == MARCA_EEPROM &&
        datos.longitud >= 1 &&
        datos.longitud <= MAX_SECUENCIA &&
        datos.cursorX < 8 &&
        datos.cursorY < 8 &&
        datos.colorCursor <= AMARILLO &&
        datos.estado <= ERROR_JUEGO &&
        datos.indice <= datos.longitud)
    {
        nivel = datos.nivel;
        record = datos.record;
        longitud = datos.longitud;
        indiceJugador = datos.indice;
        cursorX = datos.cursorX;
        cursorY = datos.cursorY;
        colorCursor = datos.colorCursor;
        estado = datos.estado;

        for (uint8_t i = 0; i < MAX_SECUENCIA; i++)
            secuencia[i] = datos.secuencia[i];
    }
    else
    {
        nivel = 1;
        record = 0;
        longitud = 1;
        indiceJugador = 0;
        cursorX = 3;
        cursorY = 3;
        colorCursor = VERDE;
        estado = MODO_LIBRE;

        generarElemento(0);
        guardarJuego();
    }
}

/* =====================================================
   JUEGO
   ===================================================== */

static void iniciarJuego(void)
{
    nivel = 1;
    longitud = 1;
    indiceJugador = 0;

    generarElemento(0);

    estado = MOSTRAR;
    guardarJuego();
}

static void mostrarSecuencia(void)
{
    for (uint8_t i = 0; i < longitud; i++)
    {
        matrizLimpiar();

        matrizPixel(secuencia[i].x,
                    secuencia[i].y,
                    secuencia[i].color);

        sonidoColor(secuencia[i].color);

        esperar_ms(380);
        matrizLimpiar();
        esperar_ms(200);
    }

    indiceJugador = 0;
    estado = TURNO_JUGADOR;
    guardarJuego();
    matrizCursor();
}

static void procesarExito(void)
{
    matrizLimpiar();

    for (uint8_t i = 0; i < TOTAL_LEDS; i++)
        ws2812_enviarColor(0, 100, 0);

    matrizMostrar();
    buzzer(880, 180);
    esperar_ms(200);

    if (nivel < 255)
        nivel++;

    if (nivel > record)
        record = nivel;

    generarNuevoElemento();
    indiceJugador = 0;
    estado = MOSTRAR;

    guardarJuego();
}

static void procesarError(void)
{
    for (uint8_t i = 0; i < 3; i++)
    {
        // Iluminar la matriz en rojo.
        for (uint8_t j = 0; j < TOTAL_LEDS; j++)
            ws2812_enviarColor(100, 0, 0);

        matrizMostrar();
        buzzer(150, 200);

        matrizLimpiar();
        esperar_ms(150);
    }

    nivel = 1;
    longitud = 1;
    indiceJugador = 0;

    generarElemento(0);

    estado = MODO_LIBRE;
    guardarJuego();
    matrizCursor();
}

static void comprobarPosicion(void)
{
    Elemento esperado = secuencia[indiceJugador];

    if (cursorX == esperado.x && cursorY == esperado.y)
    {
        sonidoColor(esperado.color);
        indiceJugador++;

        if (indiceJugador >= longitud)
            estado = EXITO;
    }
    else
    {
        estado = ERROR_JUEGO;
    }

    guardarJuego();
}

/* =====================================================
   JOYSTICK
   ===================================================== */

static void moverCursor(void)
{
    uint16_t x = ADC;
    uint16_t y;

    // Leer eje X.
    ADMUX = (ADMUX & 0xF0) | JOY_X;
    ADCSRA |= (1 << ADSC);

    while (ADCSRA & (1 << ADSC))
        ;

    x = ADC;

    // Leer eje Y.
    ADMUX = (ADMUX & 0xF0) | JOY_Y;
    ADCSRA |= (1 << ADSC);

    while (ADCSRA & (1 << ADSC))
        ;

    y = ADC;

    uint8_t movio = 0;

    if (x < 350 && cursorX > 0)
    {
        cursorX--;
        movio = 1;
    }
    else if (x > 650 && cursorX < 7)
    {
        cursorX++;
        movio = 1;
    }

    if (y < 350 && cursorY > 0)
    {
        cursorY--;
        movio = 1;
    }
    else if (y > 650 && cursorY < 7)
    {
        cursorY++;
        movio = 1;
    }

    if (movio)
    {
        matrizCursor();
        esperar_ms(150);
    }
}

/* =====================================================
   INICIALIZACIÓN
   ===================================================== */

static void inicializar(void)
{
    // Matriz: PD6 salida.
    LED_DDR |= (1 << LED_PIN);
    LED_PORT &= ~(1 << LED_PIN);

    // Buzzer: PD3 salida.
    DDRD |= (1 << BUZZER_PIN);
    PORTD &= ~(1 << BUZZER_PIN);

    // Botón del joystick con resistencia pull-up.
    DDRD &= ~(1 << JOY_SW);
    PORTD |= (1 << JOY_SW);

    // Entradas analógicas A0 y A1.
    DDRC &= ~((1 << JOY_X) | (1 << JOY_Y));

    // ADC habilitado, prescaler 128.
    ADMUX = (1 << REFS0);
    ADCSRA = (1 << ADEN) |
             (1 << ADPS2) |
             (1 << ADPS1) |
             (1 << ADPS0);

    // Inicializar semilla a partir de lecturas del ADC.
    ADMUX = (1 << REFS0) | JOY_X;

    for (uint8_t i = 0; i < 8; i++)
    {
        ADCSRA |= (1 << ADSC);
        while (ADCSRA & (1 << ADSC))
            ;

        semilla ^= (uint8_t)ADC;
    }

    if (semilla == 0)
        semilla = 37;

    matrizLimpiar();
    cargarJuego();
}

/* =====================================================
   PROGRAMA PRINCIPAL
   ===================================================== */

int main(void)
{
    inicializar();

    while (1)
    {
        if (estado == MODO_LIBRE)
        {
            moverCursor();

            uint8_t boton = (PIND & (1 << JOY_SW)) ? 1 : 0;

            if (boton == 0 && botonAnterior == 1)
            {
                tiempoPulsado = 0;

                while (!(PIND & (1 << JOY_SW)))
                {
                    esperar_ms(10);

                    if (tiempoPulsado < 2000)
                        tiempoPulsado += 10;
                }

                if (tiempoPulsado >= 1000)
                {
                    iniciarJuego();
                }
                else
                {
                    colorCursor = (aleatorio() % 4);

                    matrizCursor();
                    guardarJuego();
                }
            }

            botonAnterior = boton;
            matrizCursor();
        }
        else if (estado == MOSTRAR)
        {
            mostrarSecuencia();
        }
        else if (estado == TURNO_JUGADOR)
        {
            moverCursor();

            if (!(PIND & (1 << JOY_SW)))
            {
                esperar_ms(30);

                if (!(PIND & (1 << JOY_SW)))
                {
                    comprobarPosicion();

                    while (!(PIND & (1 << JOY_SW)))
                        ;

                    esperar_ms(30);
                }
            }

            if (estado == EXITO)
                procesarExito();

            if (estado == ERROR_JUEGO)
                procesarError();
        }
        else if (estado == EXITO)
        {
            procesarExito();
        }
        else if (estado == ERROR_JUEGO)
        {
            procesarError();
        }
    }
}
