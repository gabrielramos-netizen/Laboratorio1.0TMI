#define F_CPU 16000000UL

// Direccion I2C del expansor PCF8574 (0x27 o 0x3F segun el modulo).
// OJO: este define NO afecta a TWI_LCD.c. Si tu pantalla es 0x3F,
// cambia el valor por defecto dentro de TWI_LCD.c.
#define PCF8574 0x27

#include <avr/io.h>
#include <avr/eeprom.h>
#include <util/delay.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "SPI.h"
#include "UART.h"
#include "RC522.h"
#include "twi.h"
#include "TWI_LCD.h"

/* ==========================================================
   CONFIGURACION DE CUENTAS Y EEPROM
   ========================================================== */

#define NUM_CUENTAS     3
#define SALDO_INICIAL   1000
#define MARCA_VALIDACION 0xA5
#define MAX_INTENTOS    3
#define T_LED_MS        500

typedef struct
{
    uint8_t uid[4];
    uint8_t pin[4];
    uint16_t saldo;
} Cuenta;

Cuenta cuentas[NUM_CUENTAS];

Cuenta EEMEM cuentas_eeprom[NUM_CUENTAS];
uint8_t EEMEM marca_eeprom;

/* ==========================================================
   PINES

   Teclado:   Filas PC0-PC3, Columnas PD2-PD5
   LED verde: PB0
   LED rojo:  PD6
   Buzzer:    PD7
   UART:      PD0 y PD1
   RC522:     PB1 a PB5
   LCD I2C:   PC4 y PC5
   ========================================================== */

const char mapa_teclado[4][4] =
{
    {'1', '2', '3', 'A'},
    {'4', '5', '6', 'B'},
    {'7', '8', '9', 'C'},
    {'*', '0', '#', 'D'}
};

/* ==========================================================
   LCD (16 caracteres por linea)
   ========================================================== */

void lcd_posicion(uint8_t fila, uint8_t columna)
{
    if (fila == 0)
        twi_lcd_cmd(0x80 + columna);
    else
        twi_lcd_cmd(0xC0 + columna);
}

void lcd_linea(uint8_t fila, const char *texto)
{
    uint8_t i = 0;

    lcd_posicion(fila, 0);

    while (texto[i] != '\0' && i < 16)
    {
        twi_lcd_dwr(texto[i]);
        i++;
    }

    while (i < 16)
    {
        twi_lcd_dwr(' ');
        i++;
    }
}

void lcd_mensaje(const char *linea1, const char *linea2)
{
    lcd_linea(0, linea1);
    lcd_linea(1, linea2);
}

/* ==========================================================
   TECLADO 4x4
   ========================================================== */

void teclado_inicializar(void)
{
    // PC0-PC3 salidas (filas). Se preservan PC4-PC7 (SDA y SCL).
    DDRC = (DDRC & 0xF0) | 0x0F;
    PORTC = (PORTC & 0xF0) | 0x0F;

    // PD2-PD5 entradas con pull-up (columnas).
    DDRD &= ~0x3C;
    PORTD |= 0x3C;
}

char teclado_escanear(void)
{
    for (uint8_t fila = 0; fila < 4; fila++)
    {
        PORTC = (PORTC & 0xF0) | 0x0F;
        PORTC &= ~(1 << fila);

        _delay_us(5);

        for (uint8_t columna = 0; columna < 4; columna++)
        {
            if (!(PIND & (1 << (PD2 + columna))))
            {
                PORTC = (PORTC & 0xF0) | 0x0F;
                return mapa_teclado[fila][columna];
            }
        }
    }

    PORTC = (PORTC & 0xF0) | 0x0F;
    return 0;
}

char teclado_leer(void)
{
    char tecla = 0;

    while (tecla == 0)
    {
        tecla = teclado_escanear();
        _delay_ms(15);
    }

    _delay_ms(20);

    while (teclado_escanear() != 0)
    {
        _delay_ms(10);
    }

    return tecla;
}

/* ==========================================================
   LEDS Y BUZZER
   LED verde: operacion exitosa
   LED rojo:  error
   Buzzer:    SOLO tras 3 intentos fallidos de PIN
   ========================================================== */

void indicadores_inicializar(void)
{
    DDRB |= (1 << PB0);
    PORTB &= ~(1 << PB0);

    DDRD |= (1 << PD6) | (1 << PD7);
    PORTD &= ~((1 << PD6) | (1 << PD7));
}

void buzzer_tono(uint16_t duracion_ms)
{
    // Aproximadamente 2 kHz (buzzer pasivo). Para uno activo
    // tambien funciona: simplemente suena mientras dura.
    for (uint32_t i = 0; i < (uint32_t)duracion_ms * 2; i++)
    {
        PORTD ^= (1 << PD7);
        _delay_us(250);
    }

    PORTD &= ~(1 << PD7);
}

void indicar_exito(void)
{
    PORTB |= (1 << PB0);
    _delay_ms(T_LED_MS);
    PORTB &= ~(1 << PB0);
}

void indicar_error(void)
{
    PORTD |= (1 << PD6);
    _delay_ms(T_LED_MS);
    PORTD &= ~(1 << PD6);
}

void indicar_bloqueo(void)
{
    PORTD |= (1 << PD6);
    buzzer_tono(1500);
    PORTD &= ~(1 << PD6);
}

/* ==========================================================
   LECTOR RFID
   ========================================================== */

uint8_t leer_uid(uint8_t uid[4])
{
    // La libreria puede escribir hasta 16 bytes.
    uint8_t datos[16] = {0};
    uint8_t hay_datos = 0;

    mfrc522_standard(datos);

    for (uint8_t i = 0; i < 4; i++)
    {
        uid[i] = datos[i];

        if (datos[i] != 0)
            hay_datos = 1;
    }

    return hay_datos;
}

uint8_t uid_igual(const uint8_t a[4], const uint8_t b[4])
{
    for (uint8_t i = 0; i < 4; i++)
    {
        if (a[i] != b[i])
            return 0;
    }

    return 1;
}

int8_t buscar_cuenta(const uint8_t uid[4])
{
    for (uint8_t i = 0; i < NUM_CUENTAS; i++)
    {
        if (uid_igual(uid, cuentas[i].uid))
            return (int8_t)i;
    }

    return -1;
}

// La libreria no hace HALT, asi que una tarjeta quieta puede fallar
// algunas lecturas. Se exigen varios fallos seguidos para confirmar
// que la tarjeta realmente se retiro.
void esperar_retirar_tarjeta(void)
{
    uint8_t uid[4];
    uint8_t sin_tarjeta = 0;

    lcd_mensaje("Retire tarjeta", "Por favor");

    while (sin_tarjeta < 5)
    {
        if (leer_uid(uid))
            sin_tarjeta = 0;
        else
            sin_tarjeta++;

        _delay_ms(100);
    }
}

/* ==========================================================
   TECLADO: PIN Y MONTO
   ========================================================== */

void leer_pin(uint8_t pin[4], const char *titulo)
{
    uint8_t cantidad = 0;
    char texto[17];

    lcd_mensaje(titulo, "PIN: ");

    while (cantidad < 4)
    {
        char tecla = teclado_leer();

        if (tecla >= '0' && tecla <= '9')
        {
            pin[cantidad] = tecla - '0';
            cantidad++;
        }
        else if (tecla == '*')
        {
            cantidad = 0;
        }

        strcpy(texto, "PIN: ");

        for (uint8_t i = 0; i < cantidad; i++)
            texto[5 + i] = '*';

        texto[5 + cantidad] = '\0';

        lcd_linea(1, texto);
    }
}

uint8_t pin_correcto(const uint8_t ingresado[4], const uint8_t guardado[4])
{
    for (uint8_t i = 0; i < 4; i++)
    {
        if (ingresado[i] != guardado[i])
            return 0;
    }

    return 1;
}

uint16_t leer_monto(void)
{
    char buffer[6] = "";
    uint8_t cantidad = 0;

    lcd_mensaje("Monto #=OK *=BOR", "");

    while (1)
    {
        char tecla = teclado_leer();

        if (tecla >= '0' && tecla <= '9' && cantidad < 5)
        {
            buffer[cantidad] = tecla;
            cantidad++;
            buffer[cantidad] = '\0';
        }
        else if (tecla == '*')
        {
            if (cantidad > 0)
            {
                cantidad--;
                buffer[cantidad] = '\0';
            }
        }
        else if (tecla == '#')
        {
            if (cantidad == 0)
                return 0;

            uint32_t valor = 0;

            for (uint8_t i = 0; i < cantidad; i++)
                valor = valor * 10 + (buffer[i] - '0');

            if (valor > 65535UL)
                return 0;

            return (uint16_t)valor;
        }

        lcd_linea(1, buffer);
    }
}

/* ==========================================================
   ALMACENAMIENTO PERSISTENTE
   ========================================================== */

void guardar_cuenta(uint8_t indice)
{
    eeprom_update_block(
        &cuentas[indice],
        &cuentas_eeprom[indice],
        sizeof(Cuenta)
    );
}

void cargar_cuentas(void)
{
    eeprom_read_block(
        cuentas,
        cuentas_eeprom,
        sizeof(cuentas)
    );
}

uint8_t uid_duplicado(const uint8_t uid[4], uint8_t cantidad)
{
    for (uint8_t i = 0; i < cantidad; i++)
    {
        if (uid_igual(uid, cuentas[i].uid))
            return 1;
    }

    return 0;
}

/* ==========================================================
   REGISTRO INICIAL DE LAS TRES CUENTAS
   ========================================================== */

void configurar_cuentas(void)
{
    uint8_t uid[4];
    uint8_t pin[4];
    char linea[17];

    for (uint8_t i = 0; i < NUM_CUENTAS; i++)
    {
        snprintf(linea, sizeof(linea), "Registrar %u/3", i + 1);

        while (1)
        {
            lcd_mensaje(linea, "Acerque tarjeta");

            while (!leer_uid(uid))
            {
                _delay_ms(200);
            }

            if (uid_duplicado(uid, i))
            {
                lcd_mensaje("Tarjeta repetida", "Use otra tarjeta");
                indicar_error();
                esperar_retirar_tarjeta();
                continue;
            }

            esperar_retirar_tarjeta();
            break;
        }

        for (uint8_t j = 0; j < 4; j++)
            cuentas[i].uid[j] = uid[j];

        leer_pin(pin, "Defina PIN (4 d)");

        for (uint8_t j = 0; j < 4; j++)
            cuentas[i].pin[j] = pin[j];

        cuentas[i].saldo = SALDO_INICIAL;

        guardar_cuenta(i);

        lcd_mensaje("Cuenta guardada", "Correctamente");
        indicar_exito();
        _delay_ms(500);
    }

    // La marca se escribe al final, con las 3 cuentas registradas.
    eeprom_update_byte(&marca_eeprom, MARCA_VALIDACION);

    lcd_mensaje("Registro listo", "Cajero iniciado");
    _delay_ms(1500);
}

/* ==========================================================
   OPERACIONES BANCARIAS
   ========================================================== */

void consultar_saldo(uint8_t indice)
{
    char linea[17];

    snprintf(linea, sizeof(linea), "Saldo: %u", cuentas[indice].saldo);

    lcd_mensaje("Saldo disponible", linea);
    indicar_exito();
    _delay_ms(1500);
}

void depositar(uint8_t indice)
{
    uint16_t monto = leer_monto();

    if (monto == 0)
    {
        lcd_mensaje("Monto invalido", "Cancelado");
        indicar_error();
        _delay_ms(1000);
        return;
    }

    uint32_t nuevo_saldo = (uint32_t)cuentas[indice].saldo + monto;

    if (nuevo_saldo > 65535UL)
    {
        lcd_mensaje("Monto excesivo", "No se deposito");
        indicar_error();
        _delay_ms(1000);
        return;
    }

    cuentas[indice].saldo = (uint16_t)nuevo_saldo;
    guardar_cuenta(indice);

    lcd_mensaje("Deposito exitoso", "Saldo guardado");
    indicar_exito();
    _delay_ms(1000);
}

void retirar(uint8_t indice)
{
    uint16_t monto = leer_monto();

    if (monto == 0)
    {
        lcd_mensaje("Monto invalido", "Cancelado");
        indicar_error();
        _delay_ms(1000);
        return;
    }

    if (monto > cuentas[indice].saldo)
    {
        lcd_mensaje("Saldo insufic.", "Retiro rechazado");
        indicar_error();
        _delay_ms(1000);
        return;
    }

    cuentas[indice].saldo -= monto;
    guardar_cuenta(indice);

    lcd_mensaje("Retiro exitoso", "Saldo guardado");
    indicar_exito();
    _delay_ms(1000);
}

void i2c_escanear(void)
{
	uint8_t encontrados = 0;

	uart_print("Escaneando I2C...\r\n");

	for (uint8_t dir = 1; dir < 127; dir++)
	{
		TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN);
		while (!(TWCR & (1 << TWINT)));

		TWDR = (uint8_t)(dir << 1);
		TWCR = (1 << TWINT) | (1 << TWEN);
		while (!(TWCR & (1 << TWINT)));

		if ((TWSR & 0xF8) == 0x18)   // SLA+W con ACK
		{
			uart_print("Responde dir: ");
			uart_print_hex(dir);
			uart_print("\r\n");
			encontrados++;
		}

		TWCR = (1 << TWINT) | (1 << TWEN) | (1 << TWSTO);
		while (TWCR & (1 << TWSTO));
	}

	if (encontrados == 0)
	uart_print("Ningun dispositivo I2C responde\r\n");

	uart_print("Escaneo terminado\r\n");
}

/* ==========================================================
   MAQUINA DE ESTADOS
   ========================================================== */

typedef enum
{
    ST_ESPERA_TARJETA,
    ST_TARJETA_INVALIDA,
    ST_PEDIR_PIN,
    ST_VERIFICAR_PIN,
    ST_BLOQUEO,
    ST_MENU,
    ST_CONSULTA,
    ST_RETIRO,
    ST_DEPOSITO,
    ST_FIN
} Estado;

extern void PCF8574_write(unsigned char x);   // definida en TWI_LCD.c

static void lcd_nibble(uint8_t nibble)
{
	uint8_t d = (uint8_t)((nibble << 4) | 0x08);   // backlight ON, RS=0, RW=0

	PCF8574_write(d | 0x04);                        // EN = 1
	_delay_us(50);
	PCF8574_write(d);                               // EN = 0
	_delay_us(50);
}

void lcd_inicializar(void)
{
	_delay_ms(50);              // espera a que el LCD arranque

	lcd_nibble(0x03);
	_delay_ms(5);
	lcd_nibble(0x03);
	_delay_us(150);
	lcd_nibble(0x03);
	_delay_us(150);
	lcd_nibble(0x02);           // pasa a modo de 4 bits
	_delay_us(150);

	twi_lcd_cmd(0x28);          // 4 bits, 2 lineas
	twi_lcd_cmd(0x0C);          // display ON, cursor OFF
	twi_lcd_cmd(0x01);          // limpiar pantalla
	_delay_ms(3);
	twi_lcd_cmd(0x06);          // cursor avanza a la derecha
	_delay_ms(2);
}

/* ==========================================================
   PROGRAMA PRINCIPAL
   ========================================================== */

int main(void)
{
    uint8_t uid[4];
    uint8_t pin[4];
    char linea[17];
    Estado estado = ST_ESPERA_TARJETA;
    int8_t indice = -1;
    uint8_t intentos = 0;

    // UART a 9600 baudios.
    uart_init(103);

    // SPI y RC522.
    spi_init();

    DDRB |= (1 << PB2);
    PORTB |= (1 << PB2);

    mfrc522_resetPinInit();
    mfrc522_init();

           twi_init();
    PORTC |= (1 << PC4) | (1 << PC5);   // pull-ups internos de SDA y SCL
    uart_print("TWI listo\r\n");
    i2c_escanear();
        lcd_inicializar();
        uart_print("LCD listo\r\n");

    // Teclado e indicadores DESPUES de twi_init (que cambia DDRC).
    teclado_inicializar();
    indicadores_inicializar();

    lcd_mensaje("Cajero ATM", "Iniciando...");
    _delay_ms(1000);

    // Para volver a registrar las tarjetas: mantener pulsada la tecla D
    // al encender el sistema.
    if (teclado_escanear() == 'D')
    {
        eeprom_update_byte(&marca_eeprom, 0xFF);
        lcd_mensaje("Registro borrado", "Suelte la tecla");
        while (teclado_escanear() != 0)
            _delay_ms(10);
        _delay_ms(500);
    }

    if (eeprom_read_byte(&marca_eeprom) != MARCA_VALIDACION)
    {
        configurar_cuentas();
    }
    else
    {
        cargar_cuentas();
        lcd_mensaje("Cuentas cargadas", "Sistema listo");
        _delay_ms(1000);
    }

    while (1)
    {
        switch (estado)
        {
            case ST_ESPERA_TARJETA:
                lcd_mensaje("Cajero listo", "Acerque tarjeta");

                while (!leer_uid(uid))
                {
                    _delay_ms(200);
                }

                indice = buscar_cuenta(uid);

                if (indice < 0)
                {
                    estado = ST_TARJETA_INVALIDA;
                }
                else
                {
                    intentos = 0;
                    lcd_mensaje("Tarjeta valida", "");
                    _delay_ms(500);
                    esperar_retirar_tarjeta();
                    estado = ST_PEDIR_PIN;
                }
                break;

            case ST_TARJETA_INVALIDA:
                lcd_mensaje("Tarjeta invalida", "Acceso denegado");
                indicar_error();
                esperar_retirar_tarjeta();
                estado = ST_ESPERA_TARJETA;
                break;

            case ST_PEDIR_PIN:
                strcpy(linea, "Intento X de 3");
                linea[8] = '1' + intentos;
                leer_pin(pin, linea);
                estado = ST_VERIFICAR_PIN;
                break;

            case ST_VERIFICAR_PIN:
                if (pin_correcto(pin, cuentas[indice].pin))
                {
                    lcd_mensaje("PIN correcto", "Bienvenido");
                    indicar_exito();
                    estado = ST_MENU;
                }
                else
                {
                    intentos++;
                    lcd_mensaje("PIN incorrecto", "Intente otra vez");
                    indicar_error();
                    estado = (intentos >= MAX_INTENTOS) ? ST_BLOQUEO : ST_PEDIR_PIN;
                }
                break;

            case ST_BLOQUEO:
                lcd_mensaje("Acceso bloqueado", "3 errores PIN");
                indicar_bloqueo();
                _delay_ms(500);
                estado = ST_ESPERA_TARJETA;
                break;

            case ST_MENU:
                lcd_mensaje("A:Saldo B:Retiro", "C:Deposito D:Fin");

                switch (teclado_leer())
                {
                    case 'A': estado = ST_CONSULTA; break;
                    case 'B': estado = ST_RETIRO;   break;
                    case 'C': estado = ST_DEPOSITO; break;
                    case 'D': estado = ST_FIN;      break;
                    default:  break;
                }
                break;

            case ST_CONSULTA:
                consultar_saldo((uint8_t)indice);
                estado = ST_MENU;
                break;

            case ST_RETIRO:
                retirar((uint8_t)indice);
                estado = ST_MENU;
                break;

            case ST_DEPOSITO:
                depositar((uint8_t)indice);
                estado = ST_MENU;
                break;

            case ST_FIN:
                lcd_mensaje("Sesion cerrada", "Hasta luego");
                _delay_ms(1000);
                estado = ST_ESPERA_TARJETA;
                break;

            default:
                estado = ST_ESPERA_TARJETA;
                break;
        }
    }
}